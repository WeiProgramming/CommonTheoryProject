/**
 * Program 7a
 * This program explores the use of Comparable interface, uses Collections and/or Collection in the solution,
 * applies generics to methods using arrays, and applies generics to methods using List ADTs.
 * CS 108-3
 * 19-Apr-18
 * @author Liliana Guerrero
 */
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

public class GenMethods {
	

	public static String getIdentificationString() {
		return "Program 7a, Liliana Guerrero";
	}

	//(1) Write the following method that returns a new ArrayList.
	//The new list contains the non duplicate (i.e., distinct) elements 
	//from the original list.

	public static <E> ArrayList<E> removeDuplicates(ArrayList<E> list){
		

		ArrayList <E> newArrayList =  new ArrayList<>(list.size());
		

		for (int i = 0; i< list.size(); i++) {
			if(!newArrayList.contains(list.get(i))) {
				newArrayList.add(list.get(i));
				

			}
		}
		return newArrayList;
		}

	//(2) Write the following method that shuffles an ArrayList. 
	//It should do this specifically by swapping two indexes determined by the use 
	//of the random class (use Random rand = new Random(340L); ), and it should do 30 of these swaps 
	//(this number was chosen arbitrarily by us for testing purposes).

	public static <E> void shuffle(ArrayList<E> list){
		

		Random random = new Random(340L);
		int numOfSwaps = 30;
		

		  for (int i = 0; i < numOfSwaps; i++) {
			  int a = random.nextInt(list.size());
			  int b = random.nextInt(list.size());
			  E temp =  list.get(a);
			  list.set(a, list.get(b));
			  list.set(b, temp);	         
		  }
	}

	//(3) Write the following method that returns the largest element 
	//in an ArrayList:

	public static <E extends Comparable<E>> E max(ArrayList<E> list) {
		E max = list.get(0);
		for (int i = 0; i < list.size(); i++) {
	

			if(list.get(i).compareTo(max) > 0) {
				max = list.get(i);
			}
		}
		return max;
		

	}

	//(4) Implement the following generic method for linear search.

	public static <E extends Comparable<E>> int linearSearch(E[] list, E key) {
		

		for (int i = 0; i < list.length; i++) {
			if (list[i].compareTo(key) >= 0) {
				return i;
			}
		}
		return -1;
	}


	//(5) Implement the following method that returns the maximum 
	//element in an array:

	public static <E extends Comparable<E>> E max(E[] list) {
		E max = list[0];
		for (int i = 0; i < list.length; i++) {
			//E element = list[i];
			if (list[i].compareTo(max) > 0) {
				max = list[i];
			}
		}

		return max;
	}

	//(6) Implement a generic method that returns the maximum 
	//element in a two-dimensional array.

	public static <E extends Comparable<E>> E max(E[][] list) {
		E max = list[0][0];
		for (int i = 0; i < list.length; i++) {
			for (int j = 0; j < list[i].length; j++) {
				if (list[i][j].compareTo(max) > 0) {
					max = list[i][j];
				}
				

			}
		}
		return max;
	}
	

	public static void main (String [] args) {
		Scanner scan = new Scanner(System.in);

			int num = scan.nextInt();

			Integer [] list = new Integer[num];

			LinkedList <Integer> linked = new LinkedList<Integer>();

			for (int i = 0; i < num; i++) {
				list[i] = scan.nextInt();
				linked.add(list[i]);

			}

			System.out.println(Arrays.toString(list));
			System.out.println(linked);
			
			
			
			


		
////		Read in a number n that represents the number of elements in the lists.
//		int numOfElements = scan.nextInt();
//		
////		Read in n elements to initialize and fill an array of Integers named 'list'
//		//while simultaneously initializing a linked list of Integers named 'linked' from the same input.
//		int[] list = new int[numOfElements];
//		List<Integer> linked = new LinkedList<Integer>();
//		
//		for(int i = 0; i < numOfElements; i++) {
//			list[i] = scan.nextInt();
//		}
////		Print 'list'. (use Arrays.toString(array))
//		Arrays.toString(list);
////
////		Print 'linked' (just put 'linked' into print statement)
//		System.out.println(linked);
//		
//		Read in k key value to search for in list.
			int k = scan.nextInt();
//
//		Call linearSearch(list, k) and print the result: Key k was found at position result, or Key k was not found.
		if(linearSearch(list, k) == -1) {
			System.out.println("Key " + k + " was not found");
		}
		else {
			System.out.println("Key " + k + " was found at position " + linearSearch(list, k));
		}
//		
////		Call max(list) and print the result: 'Result' is the max element
		System.out.println(max(list) + " is the max element");
		
////		Read in an integer m for first dimension of a 2-D array.
//		int m = scan.nextInt();
////		
//////		Read in an integer p for second dimension of a 2-D array.
//		int p = scan.nextInt();
////		
//////		Initialize a 2-D array using m and p named 'list2'
////
////		
//////		Read in m x p elements to fill 'list2'.
//////		Print 'list2'. You can not just use a single print statement, but will instead need to implement nested for loops. (Format: rows of data on separate lines with a space in between each data)
//////		Example:
//////		1 2 3 4 
//////		2 3 4 5
//////		3 4 5 6
//		int[][] list2 = new int[m][p];
//		
//		for(int i = 0; i < m; i++) {
//			for(int j = 0; j < p; j++) {
//				list2[m][p] = scan.nextInt();
//				//System.out.print(list2[m][p]);
//			}
//			//System.out.println();
//
//		}
		
//		for(int i = 0; i < m; i++){
//			for(int j = i; j < p; j++) {
//				
//			}
//		}
//		
////		Call max(list2) and print the result: 'Result' is the max element
//		System.out.println(max(list2) + " is the max element");
//		
////		Instantiate an ArrayList of type Integer named 'alist' from 'linked' (meaning 'alist' is a copy of 'linked')
//		int j;
//		
////		Print out 'alist' using System.out.println(alist);
//		System.out.println(alist);
//		
////		Call removeDuplicates using 'alist' as the parameter
//		remove(alist);
//		
////		Print the now unique 'alist' using System.out.println(alist);
//		System.out.println(alist);
//		
////		Call shuffle using 'alist' as the parameter.
//		shuffle(alist);
//		
////		Print 'alist' again using System.out.println(alist);
//		System.out.println(alist);
//		
////		Find the max element of 'alist' and print: 'Result' is the max element
//		System.out.println(max(alist) + " is the max element");

	}
}